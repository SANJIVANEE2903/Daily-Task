package Demo01;

public class Program04 {
	public static void main(String[] args) {
		String s1 = "SUNBEAM"; // String Literals
		String s2 = "sunbeam";
		String s3 = s2.toUpperCase();
		String s4 = s2.toLowerCase();
		

		System.out.println("s1 - " + s1);
		System.out.println("s2 - " + s2);
		System.out.println("s3 - " + s3);
		System.out.println("(s1==s3) - " + (s1 == s3));
		System.out.println("(s1==s4) - " + (s1 == s4));

}
}
