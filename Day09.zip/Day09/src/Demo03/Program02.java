package Demo03;

import java.util.StringTokenizer;

public class Program02 {
	public static void main(String[] args) {
		String s = "wwww.sunbeaminfo.com";
		System.out.println("OG string: " +s);
		System.out.println("Token ->");
		
		StringTokenizer st = new StringTokenizer((s));
		while(st.hasMoreTokens())
			System.out.println(st.nextToken());

	}
}
