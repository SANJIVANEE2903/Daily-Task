package string;

public class StringsMethods {
    public static void main(String[] args) {
        // Initialize the sentence
        String sentence = "Welcome to Java Class at Sunbeam Institute       ";

        // Check if the sentence contains "Class"
        boolean sentenceContainsClass = sentence.contains("Class");
        System.out.println("Does the sentence contain 'Class': " + sentenceContainsClass);

        // Convert to lowercase
        sentence = sentence.toLowerCase();
        System.out.println("Lower case stmt: " + sentence);

        // Convert to uppercase and print
        String upper = sentence.toUpperCase();
        System.out.println("Upper case stmt: " + upper);

        // equals() and equalsIgnoreCase()
        String s1 = "class", s2 = "Class";
        boolean s = s1.equals(s2);
        System.out.println(".equals returns: " + s);
        boolean strIgnore = s1.equalsIgnoreCase(s2);
        System.out.println(".equalsIgnoreCase returns: " + strIgnore);

        // substring
        String aNewString = sentence.substring(8, 49);
        System.out.println("Substring is: " + aNewString);

        // compareTo()
        String str1 = "Oracle", str2 = "Corporation";
        int retval = str1.compareTo(str2);
        if (retval < 0) {
            System.out.println("str1 is greater than str2");
        } else if (retval == 0) {
            System.out.println("str1 is equal to str2");
        } else {
            System.out.println("str1 is less than str2");
        }

        // Trim the sentence
        String trimmed = sentence.trim();
        System.out.println("Trimmed sentence: " + trimmed);

        // Get the length
        System.out.println("Length of sentence: " + sentence.length());

        // Replace characters
        String r = sentence.replace('e', 'Y'); // 'E' won't work due to lowercase
        System.out.println("Replace of char 'e' with 'Y': " + r);
    }
}
