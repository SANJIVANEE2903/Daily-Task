package string;

public class StringConstructorsDemo {
    public static void main(String[] args) {
        // 1. Default constructor (String literal)
        String str1 = "Hello, World!";
        System.out.println("String literal: " + str1);

        // 2. Constructor with char array
        char[] charArray = {'J', 'a', 'v', 'a'};
        String str2 = new String(charArray);
        System.out.println("From char array: " + str2);

        // 3. Constructor with char array and offset
        String str3 = new String(charArray, 1, 2); // "av"
        System.out.println("From char array with offset: " + str3);

        // 4. Constructor with byte array
        byte[] byteArray = {65, 66, 67, 68}; // ASCII values for A, B, C, D
        String str4 = new String(byteArray);
        System.out.println("From byte array: " + str4);

        // 5. Constructor with byte array and offset
        String str5 = new String(byteArray, 1, 2); // "BC"
        System.out.println("From byte array with offset: " + str5);

        // 6. Constructor with another String
        String str6 = new String(str1);
        System.out.println("From another String: " + str6);

        // 7. Constructor with StringBuffer
        StringBuffer stringBuffer = new StringBuffer("StringBuffer Example");
        String str7 = new String(stringBuffer);
        System.out.println("From StringBuffer: " + str7);

        // 8. Constructor with StringBuilder
        StringBuilder stringBuilder = new StringBuilder("StringBuilder Example");
        String str8 = new String(stringBuilder);
        System.out.println("From StringBuilder: " + str8);
    }
}
