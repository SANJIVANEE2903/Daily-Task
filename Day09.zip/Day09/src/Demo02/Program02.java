package Demo02;

public class Program02 {
	public static void main(String[] args) {
		StringBuilder sb1 = new StringBuilder("sunbeam"); // Mutable sequence of characters
		sb1.append(" infotech");
		System.out.println("sb1 - " + sb1);
	}

}
