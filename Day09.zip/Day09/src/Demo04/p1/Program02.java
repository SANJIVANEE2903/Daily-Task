package Demo04.p1;

// Removed: import com.sun.jdi.IntegerType; → ❌ Not needed

// Box1 class before generics (till Java 1.4)
class Box1 {
	private Object obj;

	public void setObj(Object obj) {
		this.obj = obj;
	}

	public Object getObj() {
		return obj;
	}
}

public class Program02 {
	public static void main(String[] args) {
		Box b1 = new Box();
		b1.setObj(new Integer(10)); 
		Integer i1 = (Integer) b1.getObj(); 
		System.out.println("i1 = " + i1);

		Box b2 = new Box();
		b2.setObj("sunbeam"); 
		String s1 = (String) b2.getObj(); 
		System.out.println("s1 = " + s1);

		Box b3 = new Box();
		b3.setObj("10.20"); // ❌ Storing a String, but trying to cast it to Integer
		// This will throw ClassCastException at runtime
		try {
			Integer d1 = (Integer) b3.getObj(); // ❌ Incorrect cast
			System.out.println("d1 = " + d1);
		} catch (ClassCastException e) {
			System.out.println("Runtime Error: " + e.getMessage());
		}
	}
}
