package Demo04.p2;

import java.util.Scanner;

public class GenericsForLoop {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Ask user for the size of the array
        System.out.print("Enter the number of elements in the array: ");
        int n = sc.nextInt();

      
        int[] arr = new int[n];
        System.out.println("Enter " + n + " integer values:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        // Call sum method and display result
        int s = sum(arr);
        System.out.println("Sum of array elements: " + s);

        sc.close();
    }

    public static int sum(int[] arr) {
        int sum = 0;
        for (int var : arr) {
            sum += var;
        }
        return sum;
    }
}
