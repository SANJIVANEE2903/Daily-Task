package Demo04.p2;

public class Demo {
    public <T> void genericsMethod(T data) {
        System.out.println("Generic method:");
        System.out.println("Data passed: " + data);
    }
}
