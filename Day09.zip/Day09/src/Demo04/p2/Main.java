package Demo04.p2;

import java.util.Scanner;

public class Main { 
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Demo demo = new Demo(); // 

        System.out.println("Enter a string:");
        String userInput = sc.nextLine();
        demo.genericsMethod(userInput); // ✅ OK

        System.out.println("Enter an integer:");
        int numInput = sc.nextInt();
        demo.genericsMethod(numInput); // ✅ OK

        sc.close();
    }
}
