package com.dkte;

public class StarPattern {
    public static void main(String[] args) {
        int rows = 5;

        for (int i = 1; i <= rows; i++) {
            // Print leading spaces for pyramid shape
            for (int space = 1; space <= (rows - i); space++) {
                System.out.print(" ");
            }

            // Print stars with spaces between them
            for (int star = 1; star <= i; star++) {
                System.out.print("* ");
            }

            // Move to next line
            System.out.println();
        }
    }
}
