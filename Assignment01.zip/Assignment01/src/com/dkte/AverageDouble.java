package com.dkte;

import java.util.Scanner;

public class AverageDouble {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter first double value: ");
        if (!sc.hasNextDouble()) {
            System.out.println("Error: 1st input is not a valid double");
            sc.close();
            return;
        }
        double num1 = sc.nextDouble();

        System.out.println("Enter second double value: ");
        if (!sc.hasNextDouble()) {
            System.out.println("Error: 2nd input is not a valid double");
            sc.close();
            return;
        }
        double num2 = sc.nextDouble();

        double avg = (num1 + num2) / 2;
        System.out.println("Average = " + avg);

        sc.close();
    }
}
