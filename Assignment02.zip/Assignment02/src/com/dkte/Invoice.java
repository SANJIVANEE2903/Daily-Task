package com.dkte;

public class Invoice {
    private String part_number;
    private String part_description;
    private int quantity;
    private double price;

    public Invoice() {
    }

    public Invoice(String part_number, String part_description, int quantity, double price) {
        this.part_number = part_number;
        this.part_description = part_description;
        this.quantity = (quantity >= 0) ? quantity : 0;
        this.price = (price >= 0) ? price : 0.0;
    }

    public String getPart_number() {
        return part_number;
    }

    public void setPart_number(String part_number) {
        this.part_number = part_number;
    }

    public String getPart_description() {
        return part_description;
    }

    public void setPart_description(String part_description) {
        this.part_description = part_description;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = (quantity >= 0) ? quantity : 0;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = (price >= 0) ? price : 0.0;
    }

    public double getInvoiceAmount() {
        return quantity * price;
    }
}
