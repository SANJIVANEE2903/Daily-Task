package com.dkte;

public class InvoiceTest {
           
	 public static void main(String[] args) {
	        Invoice invoice1 = new Invoice("A101", "Hammer", 5, 299.99);

	        System.out.println("Part Number: " + invoice1.getPart_number());
	        System.out.println("Part Description: " + invoice1.getPart_description());
	        System.out.println("Quantity: " + invoice1.getQuantity());
	        System.out.println("Price per item: ₹" + invoice1.getPrice());
	        System.out.println("Invoice Amount: ₹" + invoice1.getInvoiceAmount());
	    }
}
