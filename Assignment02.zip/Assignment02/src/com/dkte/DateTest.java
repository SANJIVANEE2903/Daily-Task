package com.dkte;

public class DateTest {
   public static void main(String[] args) {
	   Date date = new Date(20,3,2020);
	   date.displayDate();
	   date.setDay(27);
	   date.setMonth(7);
	   date.setYear(2021);
	   date.displayDate();
   }
}
