package com.dkte;


public class Apple extends Fruit {
    public Apple(String name, double weight, String color) {
        super(name, weight, color, "sweet n sour");
    }
}
