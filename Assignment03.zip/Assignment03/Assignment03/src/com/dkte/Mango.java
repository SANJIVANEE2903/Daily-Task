package com.dkte;

public class Mango extends Fruit {
    public Mango(String name, double weight, String color) {
        super(name, weight, color, "sweet");
    }
}
