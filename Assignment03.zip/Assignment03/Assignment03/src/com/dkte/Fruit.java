package com.dkte;

public class Fruit {
    private String name;
    private String color;
    private double weight;
    private boolean isFresh;
    private String taste;

    public Fruit(String name, double weight, String color, String taste) {
        this.name = name;
        this.weight = weight;
        this.color = color;
        this.taste = taste;
        this.isFresh = true; // default
    }

    public String getName() {
        return name;
    }

    public boolean isFresh() {
        return isFresh;
    }

    public void setFresh(boolean fresh) {
        isFresh = fresh;
    }

    public String taste() {
        return taste;
    }

    public void printDetails() {
        System.out.println("Name: " + name);
        System.out.println("Color: " + color);
        System.out.println("Weight: " + weight);
    }
}
