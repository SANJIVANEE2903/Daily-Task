package com.dkte;

	public class Orange extends Fruit {
	    public Orange(String name, double weight, String color) {
	        super(name, weight, color, "sour");
	    }
	}

