package FruitTester;


import java.util.Scanner;
import com.dkte.*;

public class FruitTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter basket size: ");
        int size = sc.nextInt();
        Fruit[] basket = new Fruit[size];
        int counter = 0;

        int choice;
        do {
            System.out.println("\n------ MENU ------");
            System.out.println("0. Exit");
            System.out.println("1. Add Mango");
            System.out.println("2. Add Orange");
            System.out.println("3. Add Apple");
            System.out.println("4. Display names of all fruits");
            System.out.println("5. Display name, color, weight, taste of all fresh fruits");
            System.out.println("6. Mark a fruit as stale");
            System.out.println("7. Display tastes of all stale fruits");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    if (counter < basket.length) {
                        System.out.print("Enter name, weight, color of Mango: ");
                        String name = sc.next();
                        double weight = sc.nextDouble();
                        String color = sc.next();
                        basket[counter++] = new Mango(name, weight, color);
                    } else {
                        System.out.println("Basket is full!");
                    }
                    break;

                case 2:
                    if (counter < basket.length) {
                        System.out.print("Enter name, weight, color of Orange: ");
                        String name = sc.next();
                        double weight = sc.nextDouble();
                        String color = sc.next();
                        basket[counter++] = new Orange(name, weight, color);
                    } else {
                        System.out.println("Basket is full!");
                    }
                    break;

                case 3:
                    if (counter < basket.length) {
                        System.out.print("Enter name, weight, color of Apple: ");
                        String name = sc.next();
                        double weight = sc.nextDouble();
                        String color = sc.next();
                        basket[counter++] = new Apple(name, weight, color);
                    } else {
                        System.out.println("Basket is full!");
                    }
                    break;

                case 4:
                    System.out.println("Fruit names in basket:");
                    for (Fruit f : basket) {
                        if (f != null) {
                            System.out.println(f.getName());
                        }
                    }
                    break;

                case 5:
                    System.out.println("Fresh fruit details:");
                    for (Fruit f : basket) {
                        if (f != null && f.isFresh()) {
                            f.printDetails();
                            System.out.println("Taste: " + f.taste());
                            System.out.println("-----------------");
                        }
                    }
                    break;

                case 6:
                    System.out.print("Enter index to mark stale: ");
                    int idx = sc.nextInt();
                    if (idx >= 0 && idx < basket.length && basket[idx] != null) {
                        basket[idx].setFresh(false);
                        System.out.println("Marked as stale.");
                    } else {
                        System.out.println("Invalid index!");
                    }
                    break;

                case 7:
                    System.out.println("Tastes of stale fruits:");
                    for (Fruit f : basket) {
                        if (f != null && !f.isFresh()) {
                            System.out.println(f.taste());
                        }
                    }
                    break;

                case 0:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 0);

        sc.close();
    }
}

