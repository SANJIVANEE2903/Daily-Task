package COM.DKTE;

import java.util.Scanner;

public class StaffManagementSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Staff[] staffArr = new Staff[10];
        int count = 0;

        while (true) {
            System.out.println("\n--- Staff Management System ---");
            System.out.println("1. Add Teaching Staff");
            System.out.println("2. Add Lab Staff");
            System.out.println("3. Display All Teaching Staff");
            System.out.println("4. Display All Lab Staff");
            System.out.println("5. Find Specific Teaching Staff by ID");
            System.out.println("6. Find Specific Lab Staff by ID");
            System.out.println("7. Display Teaching Staff with Highest Hours");
            System.out.println("8. Display Lab Staff with Lowest Salary");
            System.out.println("9. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();
            sc.nextLine();

            try {
                switch (choice) {
                    case 1:
                        if (count >= staffArr.length) {
                            System.out.println("Staff array is full.");
                            break;
                        }
                        System.out.print("Enter Teaching Staff ID: ");
                        int tid = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter Name: ");
                        String tname = sc.nextLine();
                        System.out.print("Enter Number of Hours (>0): ");
                        int hours = sc.nextInt();
                        System.out.print("Enter Charges per Hour (>0): ");
                        double charge = sc.nextDouble();
                        sc.nextLine();
                        TeachingStaff ts = new TeachingStaff(tid, tname, hours, charge);
                        staffArr[count++] = ts;
                        System.out.println("Teaching Staff added successfully.");
                        break;

                    case 2:
                        if (count >= staffArr.length) {
                            System.out.println("Staff array is full.");
                            break;
                        }
                        System.out.print("Enter Lab Staff ID: ");
                        int lid = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter Name: ");
                        String lname = sc.nextLine();
                        System.out.print("Enter Salary (>0): ");
                        double salary = sc.nextDouble();
                        sc.nextLine();
                        LabStaff ls = new LabStaff(lid, lname, salary);
                        staffArr[count++] = ls;
                        System.out.println("Lab Staff added successfully.");
                        break;

                    case 3:
                        System.out.println("\nTeaching Staff List:");
                        boolean foundTeaching = false;
                        for (int i = 0; i < count; i++) {
                            if (staffArr[i] instanceof TeachingStaff) {
                                staffArr[i].printDetails();
                                foundTeaching = true;
                            }
                        }
                        if (!foundTeaching) System.out.println("No Teaching Staff found.");
                        break;

                    case 4:
                        System.out.println("\nLab Staff List:");
                        boolean foundLab = false;
                        for (int i = 0; i < count; i++) {
                            if (staffArr[i] instanceof LabStaff) {
                                staffArr[i].printDetails();
                                foundLab = true;
                            }
                        }
                        if (!foundLab) System.out.println("No Lab Staff found.");
                        break;

                    case 5:
                        System.out.print("Enter Teaching Staff ID to search: ");
                        int searchTid = sc.nextInt();
                        sc.nextLine();
                        boolean teachFound = false;
                        for (int i = 0; i < count; i++) {
                            if (staffArr[i] instanceof TeachingStaff && staffArr[i].getId() == searchTid) {
                                staffArr[i].printDetails();
                                teachFound = true;
                                break;
                            }
                        }
                        if (!teachFound) System.out.println("Teaching Staff not found.");
                        break;

                    case 6:
                        System.out.print("Enter Lab Staff ID to search: ");
                        int searchLid = sc.nextInt();
                        sc.nextLine();
                        boolean labFound = false;
                        for (int i = 0; i < count; i++) {
                            if (staffArr[i] instanceof LabStaff && staffArr[i].getId() == searchLid) {
                                staffArr[i].printDetails();
                                labFound = true;
                                break;
                            }
                        }
                        if (!labFound) System.out.println("Lab Staff not found.");
                        break;

                    case 7:
                        TeachingStaff maxHoursStaff = null;
                        for (int i = 0; i < count; i++) {
                            if (staffArr[i] instanceof TeachingStaff) {
                                TeachingStaff t = (TeachingStaff) staffArr[i];
                                if (maxHoursStaff == null || t.getNoOfHours() > maxHoursStaff.getNoOfHours()) {
                                    maxHoursStaff = t;
                                }
                            }
                        }
                        if (maxHoursStaff != null) {
                            System.out.println("Teaching Staff with Highest Hours:");
                            maxHoursStaff.printDetails();
                        } else {
                            System.out.println("No Teaching Staff found.");
                        }
                        break;

                    case 8:
                        LabStaff minSalaryStaff = null;
                        for (int i = 0; i < count; i++) {
                            if (staffArr[i] instanceof LabStaff) {
                                LabStaff l = (LabStaff) staffArr[i];
                                if (minSalaryStaff == null || l.getSalary() < minSalaryStaff.getSalary()) {
                                    minSalaryStaff = l;
                                }
                            }
                        }
                        if (minSalaryStaff != null) {
                            System.out.println("Lab Staff with Lowest Salary:");
                            minSalaryStaff.printDetails();
                        } else {
                            System.out.println("No Lab Staff found.");
                        }
                        break;

                    case 9:
                        System.out.println("Exiting application.");
                        sc.close();
                        System.exit(0);

                    default:
                        System.out.println("Invalid choice, try again.");
                }
            } catch (StaffException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Invalid input. Please try again.");
                sc.nextLine(); 
            }
        }
    }
}
