package COM.DKTE;

class TeachingStaff extends Staff {
    private int noOfHours;
    private double chargesPerHour;

    public TeachingStaff(int id, String name, int noOfHours, double chargesPerHour) throws StaffException {
        super(id, name);
        if (noOfHours <= 0) throw new StaffException("Number of hours must be > 0");
        if (chargesPerHour <= 0) throw new StaffException("Charges per hour must be > 0");
        this.noOfHours = noOfHours;
        this.chargesPerHour = chargesPerHour;
    }

    public int getNoOfHours() { return noOfHours; }
    public double getChargesPerHour() { return chargesPerHour; }
    public double getSalary() { return noOfHours * chargesPerHour; }

    @Override
    public void printDetails() {
        System.out.println("Teaching Staff [ID=" + getId() + ", Name=" + getName() + ", Hours=" + noOfHours 
            + ", Charges/Hour=" + chargesPerHour + ", Salary=" + getSalary() + "]");
    }
}