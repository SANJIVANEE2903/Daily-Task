package COM.DKTE;

class LabStaff extends Staff {
    private double salary;

    public LabStaff(int id, String name, double salary) throws StaffException {
        super(id, name);
        if (salary <= 0) throw new StaffException("Salary must be > 0");
        this.salary = salary;
    }

    public double getSalary() { return salary; }

    @Override
    public void printDetails() {
        System.out.println("Lab Staff [ID=" + getId() + ", Name=" + getName() + ", Salary=" + salary + "]");
    }
}