package COM.DKTE;

// Custom exception for validation errors
class StaffException extends Exception {
    public StaffException(String message) {
        super(message);
    }
}