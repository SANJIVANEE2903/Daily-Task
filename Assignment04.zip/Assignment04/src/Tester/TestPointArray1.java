package Tester;

import java.util.Scanner;
import com.dkte.Point2D;

public class TestPointArray1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // b) Accept how many points to plot
        System.out.print("Enter how many points to plot: ");
        int size = sc.nextInt();

        // c) Create suitable data structure
        Point2D[] points = new Point2D[size];

        // d) Prompt user for x & y coordinates and store
        for (int i = 0; i < size; i++) {
            System.out.println("Enter x and y for point " + i + ":");
            double x = sc.nextDouble();
            double y = sc.nextDouble();
            points[i] = new Point2D(x, y);
        }

        int choice;
        do {
            System.out.println("\n------ Menu ------");
            System.out.println("1. Display details of a specific point");
            System.out.println("2. Display all x, y coordinates");
            System.out.println("3. Calculate distance between two points");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter index: ");
                    int idx = sc.nextInt();
                    if (idx >= 0 && idx < points.length) {
                        System.out.println("Point at index " + idx + ": " + points[idx].getDetails());
                    } else {
                        System.out.println("Invalid index, pls retry!!!!");
                    }
                    break;

                case 2:
                    System.out.println("All point coordinates:");
                    for (Point2D p : points) {
                        System.out.println(p.getDetails());
                    }
                    break;

                case 3:
                    System.out.print("Enter index of start point: ");
                    int i = sc.nextInt();
                    System.out.print("Enter index of end point: ");
                    int j = sc.nextInt();
                    if (i >= 0 && i < points.length && j >= 0 && j < points.length) {
                        if (!points[i].isEqual(points[j])) {
                            double dist = points[i].calculateDistance(points[j]);
                            System.out.println("Distance between points: " + dist);
                        } else {
                            System.out.println("Points are at the same position!");
                        }
                    } else {
                        System.out.println("Invalid indices, please retry!");
                    }
                    break;

                case 4:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice, please try again!");
            }

        } while (choice != 4);

        sc.close();
    }
}
