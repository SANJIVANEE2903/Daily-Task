package Q1;

import java.util.Scanner;

public class DrivingCostCalculator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input values
        System.out.print("Enter total miles driven per day: ");
        double totalMiles = sc.nextDouble();

        System.out.print("Enter cost per gallon of gasoline: ");
        double costPerGallon = sc.nextDouble();

        System.out.print("Enter average miles per gallon: ");
        double avgMilesPerGallon = sc.nextDouble();

        System.out.print("Enter parking fees per day: ");
        double parkingFees = sc.nextDouble();

        System.out.print("Enter tolls per day: ");
        double tolls = sc.nextDouble();

        // Calculate total daily cost
        double fuelCost = (totalMiles / avgMilesPerGallon) * costPerGallon;
        double dailyCost = fuelCost + parkingFees + tolls;

        // Output result
        System.out.println("\n--- Daily Driving Cost Summary ---");
        System.out.printf("Fuel Cost: ₹%.2f\n", fuelCost);
        System.out.printf("Parking Fees: ₹%.2f\n", parkingFees);
        System.out.printf("Tolls: ₹%.2f\n", tolls);
        System.out.printf("Total Daily Cost: ₹%.2f\n", dailyCost);

        sc.close();
    }
}
