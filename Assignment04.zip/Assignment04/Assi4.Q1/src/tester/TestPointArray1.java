package tester;

import java.util.Scanner;
import com.app.geometry.Point2D;

public class TestPointArray1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of points to plot: ");
        int size = sc.nextInt();
        Point2D[] points = new Point2D[size];

        // Accept coordinates
        for (int i = 0; i < points.length; i++) {
            System.out.println("Enter x and y coordinates for point " + i + ": ");
            double x = sc.nextDouble();
            double y = sc.nextDouble();
            points[i] = new Point2D(x, y);
        }

        int choice;
        do {
            System.out.println("\nMenu:");
            System.out.println("1. Display specific point details");
            System.out.println("2. Display all point coordinates");
            System.out.println("3. Calculate distance between 2 points");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter index of the point: ");
                    int idx = sc.nextInt();
                    if (idx >= 0 && idx < points.length) {
                        System.out.println(points[idx].show());
                    } else {
                        System.out.println("Invalid index, pls retry!!!!");
                    }
                    break;

                case 2:
                    System.out.println("All Points:");
                    for (Point2D p : points) {
                        System.out.println(p.show());
                    }
                    break;

                case 3:
                    System.out.print("Enter index of start point: ");
                    int i = sc.nextInt();
                    System.out.print("Enter index of end point: ");
                    int j = sc.nextInt();
                    if (i >= 0 && i < points.length && j >= 0 && j < points.length) {
                        if (!points[i].isEqual(points[j])) {
                            double dist = points[i].calculateDistance(points[j]);
                            System.out.println("Distance between points: " + dist);
                        } else {
                            System.out.println("Points are at the same position!");
                        }
                    } else {
                        System.out.println("Invalid indices, please retry!");
                    }
                    break;

                case 4:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice, please try again!");
            }

        } while (choice != 4);

        sc.close();
    }
}
