package p1;

import java.util.Scanner;

public class DailyDrivingCostCalculator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("=== Daily Driving Cost Calculator ===");

        System.out.print("Enter total miles driven per day: ");
        double totalMiles = sc.nextDouble();

        System.out.print("Enter cost per gallon of gasoline: ");
        double costPerGallon = sc.nextDouble();

        System.out.print("Enter average miles per gallon: ");
        double milesPerGallon = sc.nextDouble();

        System.out.print("Enter parking fees per day: ");
        double parkingFees = sc.nextDouble();

        System.out.print("Enter tolls per day: ");
        double tolls = sc.nextDouble();

 
        double fuelCost = (totalMiles / milesPerGallon) * costPerGallon;


        double totalCostPerDay = fuelCost + parkingFees + tolls;

        System.out.printf("Estimated daily driving cost: ₹%.2f\n", totalCostPerDay);

        sc.close();
    }
}

