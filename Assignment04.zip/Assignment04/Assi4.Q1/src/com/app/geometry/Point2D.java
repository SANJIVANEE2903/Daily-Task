package com.app.geometry;


public class Point2D {
    private double x;
    private double y;

    // Constructor
    public Point2D(double x, double y) {
        this.x = x;
        this.y = y;
    }

    // Method to return details
    public String show() {
        return "Point Coordinates: (" + x + ", " + y + ")";
    }

    // Method to check equality
    public boolean isEqual(Point2D p) {
        return this.x == p.x && this.y == p.y;
    }

    // Method to calculate distance
    public double calculateDistance(Point2D p) {
        double dx = this.x - p.x;
        double dy = this.y - p.y;
        return Math.sqrt(dx * dx + dy * dy);
    }
}
