package com.dkte;

public class Person {
        private String name;
        private MyDate dateofBirth;
        
        public Person(String name, MyDate  dateofBirth) {
        	this.name = name;
        	this. dateofBirth= dateofBirth;
        }
        
        public void printPersonDetails() {
        	System.out.println("Nmae: "+name+ ",DOB: " + dateofBirth);
        }
        
        public String getName() {
        	return name;
        	
        }
        
        public MyDate getdateofBirth() {
        	return dateofBirth;
        	
        }
}
