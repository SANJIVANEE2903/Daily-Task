package com.dkte;


public class Employee extends Person {

    private int id;
    private String department;
    private double salary;
    private MyDate dateofJoining;

    public Employee(String name, MyDate dob, int id, String department, double salary, MyDate doj) {
        super(name, dob);
        this.id = id;
        this.department = department;
        this.salary = salary;
        this.dateofJoining = doj;
    }

    public int getId() {
        return id;
    }

    public double getSalary() {
        return salary;
    }

    public MyDate getDateOfJoining() {
        return dateofJoining;
    }

    public void printEmployeeDetails() {
        System.out.println("Details: Name: " + getName() +
                           ", DOB: " + getdateofBirth() +
                           ", ID: " + id +
                           ", Department: " + department +
                           ", Salary: " + salary +
                           ", DOJ: " + dateofJoining);
    }
}
