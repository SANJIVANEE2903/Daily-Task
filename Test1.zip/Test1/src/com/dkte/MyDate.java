package com.dkte;


public class MyDate {
    private int day;
    private int month;
    private int year;

    // Constructor with 3 parameters
    public MyDate(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;
    }

    // Getter for year (used in case 4)
    public int getYear() {
        return year;
    }

    // Optional: Print the date in dd-mm-yyyy format
    public String toString() {
        return day + "-" + month + "-" + year;
    }
}
