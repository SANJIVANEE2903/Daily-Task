package com.dkte;

import java.util.Scanner;

public class EmployeeManagement {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Employee[] employees = new Employee[10];
        int count = 0;
        int choice;

        do {
            System.out.println("\n  Employee Management System ");
            System.out.println("1. Add Employee");
            System.out.println("2. Display All Employees");
            System.out.println("3. Search Employee by ID");
            System.out.println("4. Display Employees Joined in Given Year");
            System.out.println("5. Find Employee with Maximum Salary");
            System.out.println("6. Find Employee with Minimum Salary");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    if (count >= employees.length) {
                        System.out.println("Employee array is full.");
                        break;
                    }

                    sc.nextLine(); // Clear buffer
                    System.out.print("Enter name: ");
                    String name = sc.nextLine();

                    System.out.print("Enter DOB (dd-mm-yyyy): ");
                    String dobInput = sc.nextLine();  // Example: 09-03-1984
                    String[] dobParts = dobInput.split("-");
                    int dobD = Integer.parseInt(dobParts[0]);
                    int dobM = Integer.parseInt(dobParts[1]);
                    int dobY = Integer.parseInt(dobParts[2]);
                    MyDate dob = new MyDate(dobD, dobM, dobY);

                    System.out.print("Enter ID: ");
                    int id = sc.nextInt();
                    sc.nextLine(); // Clear buffer

                    System.out.print("Enter department: ");
                    String dept = sc.nextLine();

                    System.out.print("Enter salary: ");
                    double sal = sc.nextDouble();
                    sc.nextLine(); // Clear buffer

                    System.out.print("Enter DOJ (dd-mm-yyyy): ");
                    String dojInput = sc.nextLine();  // Example: 15-01-2019
                    String[] dojParts = dojInput.split("-");
                    int dojD = Integer.parseInt(dojParts[0]);
                    int dojM = Integer.parseInt(dojParts[1]);
                    int dojY = Integer.parseInt(dojParts[2]);
                    MyDate doj = new MyDate(dojD, dojM, dojY);

                    employees[count++] = new Employee(name, dob, id, dept, sal, doj);
                    System.out.println("Employee added successfully.");
                    break;

                case 2:
                    for (int i = 0; i < count; i++) {
                        employees[i].printEmployeeDetails();
                    }
                    break;

                case 3:
                    System.out.print("Enter ID to search: ");
                    int searchId = sc.nextInt();
                    boolean found = false;
                    for (int i = 0; i < count; i++) {
                        if (employees[i].getId() == searchId) {
                            employees[i].printEmployeeDetails();
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        System.out.println("Employee not found.");
                    }
                    break;

                case 4:
                    System.out.print("Enter joining year to search: ");
                    int year = sc.nextInt();
                    boolean any = false;
                    for (int i = 0; i < count; i++) {
                        if (employees[i].getDateOfJoining().getYear() == year) {
                            employees[i].printEmployeeDetails();
                            any = true;
                        }
                    }
                    if (!any) {
                        System.out.println("No employees joined in year " + year);
                    }
                    break;

                case 5:
                    if (count == 0) {
                        System.out.println("No employees available.");
                        break;
                    }

                    Employee maxEmp = employees[0];
                    for (int i = 1; i < count; i++) {
                        if (employees[i].getSalary() > maxEmp.getSalary()) {
                            maxEmp = employees[i];
                        }
                    }

                    System.out.println("Employee with maximum salary:");
                    maxEmp.printEmployeeDetails();
                    break;

                case 6:
                    if (count == 0) {
                        System.out.println("No employees available.");
                        break;
                    }

                    Employee minEmp = employees[0];
                    for (int i = 1; i < count; i++) {
                        if (employees[i].getSalary() < minEmp.getSalary()) {
                            minEmp = employees[i];
                        }
                    }

                    System.out.println("Employee with minimum salary:");
                    minEmp.printEmployeeDetails();
                    break;

                case 7:
                    System.out.println("Exiting application.");
                    break;

                default:
                    System.out.println("Invalid choice, please try again.");
            }
        } while (choice != 7);

        sc.close();
    }
}
