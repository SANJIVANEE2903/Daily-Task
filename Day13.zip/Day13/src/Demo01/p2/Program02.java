package Demo01.p2;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

class Product1 implements Comparable<Product> {
    int pid;
    String name;
    double price;

    public Product1() {
    }

    public Product1(int pid, String name, double price) {
        this.pid = pid;
        this.name = name;
        this.price = price;
    }

    // Getters and Setters (optional but good practice)
    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product [pid=" + pid + ", name=" + name + ", price=" + price + "]";
    }

    // Natural ordering: by pid in ascending order
    @Override
    public int compareTo(Product o) {
        return this.pid - o.pid;
    }

    // Overriding equals and hashCode to use pid, name and price for equality

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        Product other = (Product) obj;

        if (pid != other.pid) return false;
        if (Double.compare(other.price, price) != 0) return false;
        return (name != null ? name.equals(other.name) : other.name == null);
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = pid;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        temp = Double.doubleToLongBits(price);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        return result;
    }
}

public class Program02 {
    public static void main(String[] args) {
        // Comparator for ordering products by price in descending order
        class ProductPriceComparator implements Comparator<Product> {
            @Override
            public int compare(Product o1, Product o2) {
                int priceComparison = Double.compare(o2.price, o1.price); // Descending order
                if (priceComparison != 0) {
                    return priceComparison;
                }
                // If prices are equal, compare by pid to avoid treating different objects as duplicates
                return Integer.compare(o1.pid, o2.pid);
            }
        }

        ProductPriceComparator priceComparator = new ProductPriceComparator();

        Set<Product> products = new TreeSet<>(priceComparator); // Sorted by price descending
        products.add(new Product(5, "Pen", 15));
        products.add(new Product(2, "Pencil", 5));
        products.add(new Product(4, "Book", 50));
        products.add(new Product(1, "Eraser", 10));
        products.add(new Product(3, "Ruler", 12));
        products.add(new Product(3, "Ruler", 12)); // Duplicate price and pid, will be ignored by TreeSet

        System.out.println("Size of products - " + products.size());

        for (Product product : products)
            System.out.println(product);
    }

    public static void main1(String[] args) {
        Set<Product> products = new TreeSet<>(); // Uses natural ordering by pid
        products.add(new Product(5, "Pen", 15));
        products.add(new Product(2, "Pencil", 5));
        products.add(new Product(4, "Book", 50));
        products.add(new Product(1, "Eraser", 10));
        products.add(new Product(3, "Ruler", 12));
        products.add(new Product(3, "Ruler", 12)); // Duplicate pid, will be ignored

        System.out.println("Size of products - " + products.size());

        for (Product product : products)
            System.out.println(product);
    }
}

