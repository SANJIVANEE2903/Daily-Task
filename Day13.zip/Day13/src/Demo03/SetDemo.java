package Demo03;

import java.util.*;

//Set interface
interface SetOperations {
 void addElement(String element);
 void removeElement(String element);
 void displayElements();
}

//HashSet implementation
class HashSetImpl implements SetOperations {
 private Set<String> set = new HashSet<>();

 public void addElement(String element) { set.add(element); }
 public void removeElement(String element) { set.remove(element); }
 public void displayElements() {
     System.out.println("HashSet: " + set);
 }
}

//LinkedHashSet implementation
class LinkedHashSetImpl implements SetOperations {
 private Set<String> set = new LinkedHashSet<>();

 public void addElement(String element) { set.add(element); }
 public void removeElement(String element) { set.remove(element); }
 public void displayElements() {
     System.out.println("LinkedHashSet: " + set);
 }
}

//TreeSet implementation
class TreeSetImpl implements SetOperations {
 private Set<String> set = new TreeSet<>();

 public void addElement(String element) { set.add(element); }
 public void removeElement(String element) { set.remove(element); }
 public void displayElements() {
     System.out.println("TreeSet: " + set);
 }
}

//Main class
public class SetDemo {
 public static void main(String[] args) {
     SetOperations hashSetOps = new HashSetImpl();
     SetOperations linkedHashSetOps = new LinkedHashSetImpl();
     SetOperations treeSetOps = new TreeSetImpl();

     // HashSet
     hashSetOps.addElement("Banana");
     hashSetOps.addElement("Apple");
     hashSetOps.addElement("Mango");
     hashSetOps.removeElement("Banana");
     hashSetOps.displayElements();

     // LinkedHashSet
     linkedHashSetOps.addElement("Banana");
     linkedHashSetOps.addElement("Apple");
     linkedHashSetOps.addElement("Mango");
     linkedHashSetOps.removeElement("Banana");
     linkedHashSetOps.displayElements();

     // TreeSet
     treeSetOps.addElement("Banana");
     treeSetOps.addElement("Apple");
     treeSetOps.addElement("Mango");
     treeSetOps.removeElement("Banana");
     treeSetOps.displayElements();
 }
}
