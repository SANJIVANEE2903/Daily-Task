package Demo03;

import java.util.*;

//Map interface
interface MapOperations {
 void putElement(String key, String value);
 void removeElement(String key);
 void displayElements();
}

//HashMap implementation
class HashMapImpl implements MapOperations {
 private Map<String, String> map = new HashMap<>();

 public void putElement(String key, String value) { map.put(key, value); }
 public void removeElement(String key) { map.remove(key); }
 public void displayElements() {
     System.out.println("HashMap: " + map);
 }
}

//LinkedHashMap implementation
class LinkedHashMapImpl implements MapOperations {
 private Map<String, String> map = new LinkedHashMap<>();

 public void putElement(String key, String value) { map.put(key, value); }
 public void removeElement(String key) { map.remove(key); }
 public void displayElements() {
     System.out.println("LinkedHashMap: " + map);
 }
}

//TreeMap implementation
class TreeMapImpl implements MapOperations {
 private Map<String, String> map = new TreeMap<>();

 public void putElement(String key, String value) { map.put(key, value); }
 public void removeElement(String key) { map.remove(key); }
 public void displayElements() {
     System.out.println("TreeMap: " + map);
 }
}

//Main class
public class MapDemo {
 public static void main(String[] args) {
     MapOperations hashMapOps = new HashMapImpl();
     MapOperations linkedHashMapOps = new LinkedHashMapImpl();
     MapOperations treeMapOps = new TreeMapImpl();

     // HashMap
     hashMapOps.putElement("101", "Alice");
     hashMapOps.putElement("103", "Charlie");
     hashMapOps.putElement("102", "Bob");
     hashMapOps.removeElement("102");
     hashMapOps.displayElements();

     // LinkedHashMap
     linkedHashMapOps.putElement("101", "Alice");
     linkedHashMapOps.putElement("103", "Charlie");
     linkedHashMapOps.putElement("102", "Bob");
     linkedHashMapOps.removeElement("102");
     linkedHashMapOps.displayElements();

     // TreeMap
     treeMapOps.putElement("101", "Alice");
     treeMapOps.putElement("103", "Charlie");
     treeMapOps.putElement("102", "Bob");
     treeMapOps.removeElement("102");
     treeMapOps.displayElements();
 }
}

