package Demo03;

public class Employee  implements Comparable<Employee>{

	private int empid;
	private String name;
	private double salary;
	
	public Employee() {
		
	}
	
	
	
	public Employee(int empid, String name, double salary) {
		this.empid = empid;
		this.name = name;
		this.salary = salary;
	}



	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", salary=" + salary + "]";
	}


public String getName() {
	return name;
}

public double getSalary() {
	return salary;
}


	@Override
	public int compareTo(Employee o) {
		
		return this.empid - o.empid;
	}

}
