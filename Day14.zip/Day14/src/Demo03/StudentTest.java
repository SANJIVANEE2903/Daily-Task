package Demo03;

import java.util.*;

public class StudentTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Student> students = new ArrayList<>();

        int choice;
        do {
            System.out.println("\n=== Student Menu ===");
            System.out.println("1. Add Student");
            System.out.println("2. Display All Students");
            System.out.println("3. Search Student by Roll No");
            System.out.println("4. Sort Students by Roll No");
            System.out.println("5. Sort Students by Name");
            System.out.println("6. Sort Students by Marks");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1: // Add Student
                    System.out.print("Enter Roll No: ");
                    int roll = sc.nextInt();
                    sc.nextLine(); 
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Marks: ");
                    double marks = sc.nextDouble();
                    students.add(new Student(roll, name, marks));
                    System.out.println("Student added successfully.");
                    break;

                case 2: // Display All Students
                    System.out.println("=== Student List ===");
                    Iterator<Student> itr = students.iterator();
                    while (itr.hasNext()) {
                        itr.next().display();
                    }
                    break;

                case 3: // Search by Roll No
                    System.out.print("Enter roll no to search: ");
                    int searchRoll = sc.nextInt();
                    boolean found = false;
                    for (Student s : students) {
                        if (s.getRollNo() == searchRoll) {
                            s.display();
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        System.out.println("Student not found.");
                    }
                    break;

                case 4: // Sort by Roll No
                    students.sort(Comparator.comparingInt(Student::getRollNo));
                    System.out.println("Sorted by roll number:");
                    for (Student s : students) {
                        s.display();
                    }
                    break;

                case 5: // Sort by Name
                    students.sort(Comparator.comparing(Student::getName));
                    System.out.println("Sorted by name:");
                    for (Student s : students) {
                        s.display();
                    }
                    break;

                case 6: // Sort by Marks
                    students.sort(Comparator.comparingDouble(Student::getMarks));
                    System.out.println("Sorted by marks:");
                    for (Student s : students) {
                        s.display();
                    }
                    break;

                case 0:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }
        } while (choice != 0);
        sc.close();
    }
}

