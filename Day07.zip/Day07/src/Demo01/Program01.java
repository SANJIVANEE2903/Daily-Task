package Demo01;

import java.util.Scanner;

interface Acceptable {
    void accept(Scanner sc);
}

interface Displayable {
    void display();
}

class Date implements Acceptable, Displayable {
    int day;
    int month;
    int year;

    @Override
    public void accept(Scanner sc) {
        System.out.print("Enter day: ");
        day = sc.nextInt();
        System.out.print("Enter month: ");
        month = sc.nextInt();
        System.out.print("Enter year: ");
        year = sc.nextInt();
    }

    @Override
    public void display() {
        System.out.println("Date: " + day + "/" + month + "/" + year);
    }
}

class Time implements Acceptable, Displayable {
    int hr;
    int min;

    @Override
    public void accept(Scanner sc) {
        System.out.print("Enter hour (0–23): ");
        hr = sc.nextInt();
        System.out.print("Enter minutes (0–59): ");
        min = sc.nextInt();
    }

    @Override
    public void display() {
        System.out.println("Time: " + String.format("%02d:%02d", hr, min));
    }
}

class Employee implements Acceptable, Displayable {
    int empId;
    String name;
    double salary;

    @Override
    public void accept(Scanner sc) {
        System.out.print("Enter employee ID: ");
        empId = sc.nextInt();
        sc.nextLine(); // consume newline
        System.out.print("Enter employee name: ");
        name = sc.nextLine();
        System.out.print("Enter salary: ");
        salary = sc.nextDouble();
    }

    @Override
    public void display() {
        System.out.println("Employee ID: " + empId);
        System.out.println("Name: " + name);
        System.out.println("Salary: ₹" + salary);
    }
}

public class Program01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Acceptable[] items = new Acceptable[3];
        Displayable[] displays = new Displayable[3];

        items[0] = new Date();
        displays[0] = (Displayable) items[0];

        items[1] = new Time();
        displays[1] = (Displayable) items[1];

        items[2] = new Employee();
        displays[2] = (Displayable) items[2];

        // Accept input
        for (Acceptable item : items) {
            item.accept(sc);
            System.out.println();
        }

        // Display data
        System.out.println("----- Output -----");
        for (Displayable d : displays) {
            d.display();
            System.out.println();
        }

        sc.close();
    }
}
