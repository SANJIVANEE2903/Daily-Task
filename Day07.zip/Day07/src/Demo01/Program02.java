package Demo01;

// Interface declarations
interface I1 {
}

interface I2 {
}

// Valid: Interface extending multiple interfaces
interface I3 extends I1, I2 {
}

// Base class
class C1 {
}

// Another class (not used in inheritance due to Java's single inheritance for classes)
class C2 {
}

// Valid: Class extending another class and implementing multiple interfaces
class C3 extends C1 implements I1, I2 {
}

public class Program02 {
    public static void main(String[] args) {
        // Object creation to show polymorphism (optional for testing)
        C3 obj = new C3();

        // Checking instanceof relationships
//		class C3 extends C1 // OK
//		class C3 extends C1,C2 // NOT OK 
//		class C3 implements I1 // OK
//		class C3 implements I1,I2 // OK
//		class C3 extends I1 // OK

//		interface I3 extends C1 // NOT OK
//		interface I3 implements C1 // NOT OK
//		interface I3 implements I1 // NOT OK
//		interface I3 extends I1 // OK
//		interface I3 extends I1, I2// OK

//		class C3 extends C1 implements I1, I2// OK
//		class C3 implements I1, I2 extends C1 // NOT OK
        System.out.println("obj instanceof C1: " + (obj instanceof C1));
        System.out.println("obj instanceof I1: " + (obj instanceof I1));
        System.out.println("obj instanceof I2: " + (obj instanceof I2));
        System.out.println("obj instanceof C3: " + (obj instanceof C3));
    }
}
