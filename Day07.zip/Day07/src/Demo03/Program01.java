package Demo03;

public class Program01 {

	public static void main(String[] args) {
		int n=10;
		int d = 0;
		int result = n/d;
		System.out.println("Result: " +result);
		System.out.println("Program Finished...");

	}

}
