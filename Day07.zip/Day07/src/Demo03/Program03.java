package Demo03;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Program03 {

    public static void main(String[] args) {
        int n = 0;
        int d = 1; // initialize denominator to 1 to avoid divide-by-zero in fallback
        Scanner sc = new Scanner(System.in);

        try {
            System.out.print("Enter the numerator - ");
            n = sc.nextInt();

            System.out.print("Enter the denominator - ");
            d = sc.nextInt();

            int result = n / d;
            System.out.println("Result - " + result);

        } catch (ArithmeticException e) {
            System.out.println("Error: Cannot divide by 0.");
        } catch (InputMismatchException e) {
            System.out.println("Error: Please enter valid integers only.");
        } finally {
            sc.close();
            System.out.println("Program Finished...");
        }
    }
}

