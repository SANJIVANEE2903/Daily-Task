package Demo04;

class Date {
    int day;
    int month;
    int year;

    public void setDay(int day) {
        if (day <= 0 || day > 31)
            throw new RuntimeException("Invalid day");
        this.day = day;
    }

    public void setMonth(int month) throws Exception {
        if (month <= 0 || month > 12)
            throw new Exception("Invalid month");
        this.month = month;
    }

    public void setYear(int year) throws Exception {
        if (year <= 0)
            throw new Exception("Invalid year");
        this.year = year;
    }

    @Override
    public String toString() {
        return "Date [day=" + day + ", month=" + month + ", year=" + year + "]";
    }
}

public class Program01 {
    public static void main(String[] args) {
        Date d1 = new Date();
        
        try {
            d1.setDay(20);
            d1.setMonth(8);
            d1.setYear(2025);
            System.out.println(d1);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
