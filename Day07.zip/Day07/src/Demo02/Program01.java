package Demo02;

public class Program01 {
    public static void main(String[] args) {
        try {
            double arr[] = new double[100000000]; // ~800 MB
            arr[0] = 10;
            System.out.println("Array initialized. arr[0] = " + arr[0]);
        } catch (OutOfMemoryError e) {
            System.out.println("Not enough memory to allocate array: " + e);
        }
    }
}
