package Demo02;

public class Program02 {
    public static void test(int n) {
        if (n == 0)
            return;
        System.out.println("n = " + n);
        test(n - 1); // recursive call with decreasing value
    }

    public static void main(String[] args) {
        test(5); // example with limit
    }
}

