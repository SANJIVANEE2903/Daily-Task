package Demo02;

public class Program03 {
	public static void test() {
		double num1;
		test();
	}

	public static void main(String[] args) {
		test();
	}

}
