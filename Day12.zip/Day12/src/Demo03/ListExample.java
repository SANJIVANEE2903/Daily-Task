package Demo03;

import java.util.ArrayList;
import java.util.List;

public class ListExample {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        
        // Add elements
        list.add("Apple");
        list.add("Banana");
        list.add("Cherry");
        list.add(1, "Date");  // Insert at index 1
        
        System.out.println("List after additions: " + list);
        
        // Get element at index 2
        System.out.println("Element at index 2: " + list.get(2));
        
        // Set element at index 3
        list.set(3, "Elderberry");
        System.out.println("List after set(3, Elderberry): " + list);
        
        // Remove element by index
        list.remove(1);
        System.out.println("List after remove(1): " + list);
        
        // Remove element by object
        list.remove("Cherry");
        System.out.println("List after remove('Cherry'): " + list);
        
        // Check if list contains "Apple"
        System.out.println("Contains Apple? " + list.contains("Apple"));
        
        // Index of "Apple"
        System.out.println("Index of Apple: " + list.indexOf("Apple"));
        
        // Size of list
        System.out.println("Size of list: " + list.size());
        
        // Sublist (from index 0 to 1)
        List<String> sublist = list.subList(0, 1);
        System.out.println("Sublist (0 to 1): " + sublist);
        
        // Clear the list
        list.clear();
        System.out.println("List after clear(): " + list);
    }
}

