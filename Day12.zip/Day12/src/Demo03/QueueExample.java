package Demo03;
import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {
    public static void main(String[] args) {
        Queue<String> queue = new LinkedList<>();
        
        // Add elements to queue
        queue.add("John");
        queue.offer("Jane");
        queue.add("Jack");
        System.out.println("Queue after additions: " + queue);
        
        // Peek at head element (does not remove)
        System.out.println("Peek: " + queue.peek());
        
        // Element at head (throws exception if empty)
        System.out.println("Element: " + queue.element());
        
        // Remove head element (throws exception if empty)
        String removed = queue.remove();
        System.out.println("Removed: " + removed);
        System.out.println("Queue after remove(): " + queue);
        
        // Poll head element (returns null if empty)
        String polled = queue.poll();
        System.out.println("Polled: " + polled);
        System.out.println("Queue after poll(): " + queue);
        
        // Remove remaining element
        queue.remove();
        System.out.println("Queue after removing last element: " + queue);
        
        // Try poll on empty queue (returns null)
        System.out.println("Poll on empty queue: " + queue.poll());
        
        // Try peek on empty queue (returns null)
        System.out.println("Peek on empty queue: " + queue.peek());
    }
}

