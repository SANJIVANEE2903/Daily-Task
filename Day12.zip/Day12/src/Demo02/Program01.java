package Demo02;


import java.util.ArrayList;

public class Program01 {

	public static void main(String[] args) {
		ArrayList<Integer> l1 = new ArrayList<>();
		l1.add(10);
		l1.add(20);
		l1.add(30);
		l1.add(40);

		l1.remove(2);
		System.out.println("l1" +l1);
	}

}

