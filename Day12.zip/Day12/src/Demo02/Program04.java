package Demo02;

import java.util.ArrayList;

public class Program04 {

    public static void main(String[] args) {
        ArrayList<Integer> l1 = new ArrayList<>();
        
        // Adding elements
        l1.add(10);
        l1.add(20);
        l1.add(30);
        l1.add(40);
        System.out.println("Initial list: " + l1);
        
        // Remove element at index 2 (the value 30)
        l1.remove(2);
        System.out.println("After remove(2): " + l1);
        
        // Add element at specific index
        l1.add(1, 25);  // add 25 at index 1
        System.out.println("After add(1, 25): " + l1);
        
        // Check if list contains an element
        boolean contains20 = l1.contains(20);
        System.out.println("List contains 20? " + contains20);
        
        // Get element at index
        int elementAt0 = l1.get(0);
        System.out.println("Element at index 0: " + elementAt0);
        
        // Set (replace) element at index 2
        l1.set(2, 35);  // replace value at index 2 with 35
        System.out.println("After set(2, 35): " + l1);
        
        // Size of ArrayList
        int size = l1.size();
        System.out.println("Size of list: " + size);
        
        // Clear all elements
        // l1.clear();
        // System.out.println("After clear(): " + l1);
        
        // Loop through list using for-each
        System.out.print("Elements in list: ");
        for (int val : l1) {
            System.out.print(val + " ");
        }
    }
}

