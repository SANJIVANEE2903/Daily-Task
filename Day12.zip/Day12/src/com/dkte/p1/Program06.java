package com.dkte.p1;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

class Employee1 implements Comparable<Employee> {
    int empid;
    String name;
    double salary;

    public Employee1() {
    }

    public Employee1(int empid, String name, double salary) {
        this.empid = empid;
        this.name = name;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee [empid=" + empid + ", name=" + name + ", salary=" + salary + "]";
    }

    @Override
    public int compareTo(Employee obj) {
        return this.empid - obj.empid;
    }
}

public class Program06 {

    public static void display(Employee[] arr) {
        for (Employee e : arr)
            System.out.println(e);
    }

    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Enter number of employees: ");
            int n = sc.nextInt();
            sc.nextLine(); // consume leftover newline

            Employee[] arr = new Employee[n];

            for (int i = 0; i < n; i++) {
                System.out.println("Enter details for employee " + (i + 1) + ":");
                System.out.print("Employee ID: ");
                int empid = sc.nextInt();
                sc.nextLine(); // consume newline
                System.out.print("Name: ");
                String name = sc.nextLine();
                System.out.print("Salary: ");
                double salary = sc.nextDouble();
                sc.nextLine(); // consume newline

                arr[i] = new Employee(empid, name, salary);
            }

            System.out.println("\nBefore Sorting - ");
            display(arr);

            System.out.println("\nSort options:");
            System.out.println("1. Sort by empid");
            System.out.println("2. Sort by name");
            System.out.println("3. Sort by salary");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    Arrays.sort(arr); // natural order by empid
                    break;
                case 2:
                    Arrays.sort(arr, (e1, e2) -> e1.name.compareTo(e2.name));
                    break;
                case 3:
                    Arrays.sort(arr, Comparator.comparingDouble(e -> e.salary));
                    break;
                default:
                    System.out.println("Invalid choice! No sorting performed.");
            }

            System.out.println("\nAfter Sorting - ");
            display(arr);
        }
    }
}

