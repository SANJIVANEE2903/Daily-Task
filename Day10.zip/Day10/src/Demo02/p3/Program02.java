package Demo02.p3;

class Box1<T> {
	private T obj;

	public void setObj(T obj) {
		this.obj = obj;
	}

	public T getObj() {
		return obj;
	}
}

class Box1Object { Object ref; }
class Box1Integer { Integer ref; }
class Box1Double { Double ref; }
class Box1String { String ref; }

public class Program02 {
	public static void main(String[] args) {
		Box<Integer> b1 = new Box<Integer>();  // OK - full type
		b1.setObj(100);
		System.out.println("b1: " + b1.getObj());

		Box<Integer> b2 = new Box<>();         // OK - type inferred (Java 7+)
		b2.setObj(200);
		System.out.println("b2: " + b2.getObj());

		Box<Integer> b3 = new Box<>();         // ✅ fixed: no raw type
		b3.setObj(300);
		System.out.println("b3: " + b3.getObj());

		Box<Object> b4 = new Box<>();          // OK - Object type
		b4.setObj("raw type replaced");
		System.out.println("b4: " + b4.getObj());

		Box<Object> b5 = new Box<>();          // OK
		b5.setObj("Object Box");
		System.out.println("b5: " + b5.getObj());

		// Box<Object> b6 = new Box<String>(); // ❌ NOT OK – Invariance error
		Box<?> b6 = new Box<String>();         // OK – wildcard allows flexibility
		System.out.println("b6: " + b6.getObj()); // null (nothing was set)
	}
}
