package Demo02.p1;

public class Program01 {

    // Generic method to display elements of any array
    public static <T> void displayArray(T[] arr) {
        for (T element : arr)
            System.out.println("element: " + element);
    }

    public static void main(String[] args) {
        System.out.println("\nInteger array:");
        Integer[] arr1 = { 10, 20, 30, 40, 50, 60 };
        displayArray(arr1);

        System.out.println("\nDouble array:");
        Double[] arr2 = { 11.22, 22.33, 33.44, 44.55 };
        displayArray(arr2);

        System.out.println("\nString array:");
        String[] arr3 = { "Anil", "Mukesh", "Ramesh", "Suresh", "Ram", "Sham" };
        displayArray(arr3);
    }
}
