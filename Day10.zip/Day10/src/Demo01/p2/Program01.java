package Demo01.p2;

// Bounded Type Parameter: T must extend Number
class Box<T extends Number> {
	private T obj;

	public void setObj(T obj) {
		this.obj = obj;
	}

	public T getObj() {
		return obj;
	}
}

public class Program01 {

	public static void main(String[] args) {
		Box<Integer> b1 = new Box<Integer>();
		b1.setObj(10);                          // Storing Integer
		Integer i1 = b1.getObj();               // Retrieving Integer
		System.out.println("i1 - " + i1);       // Output: i1 - 10

		// The following are NOT allowed due to bounded type:
		// Box<String> b2 = new Box<String>(); // ❌ Compile-time error
		// Box<Date> b2 = new Box<Date>();     // ❌ Compile-time error

		Box<Number> b2 = new Box<Number>();     // ✅ Allowed (Number is base type)
		b2.setObj(99);                          // Autoboxed as Integer
		System.out.println("b2 - " + b2.getObj());

		Box<Double> b3 = new Box<Double>();     // ✅ Allowed
		b3.setObj(3.14);
		System.out.println("b3 - " + b3.getObj());
	}
}
