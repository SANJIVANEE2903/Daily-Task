package Demo01.p4;

import java.util.Date;

class Box<T> {
	private T obj;

	public Box(T obj) {
		this.obj = obj;
	}

	public void setObj(T obj) {
		this.obj = obj;
	}

	public T getObj() {
		return obj;
	}
}

public class Program01 {

	// Upper Bounded Wildcard: only Number or its subclasses allowed
	public static void displayBox(Box<? extends Number> b) {
		System.out.println("value - " + b.getObj());
	}

	public static void main(String[] args) {
		Box<Integer> b1 = new Box<>(10);
		displayBox(b1); // OK

		Box<Double> b2 = new Box<>(10.20);
		displayBox(b2); // OK

		Box<String> b3 = new Box<>("sunbeam");
		System.out.println("b3 - " + b3.getObj()); 
		// displayBox(b3); // NOT OK

		Box<Date> b4 = new Box<>(new Date());
		System.out.println("b4 - " + b4.getObj()); 
		// displayBox(b4); // NOT OK
	}
}
