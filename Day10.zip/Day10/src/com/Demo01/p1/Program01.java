package com.Demo01.p1;


//Generic Box class
class Box<T> {
 private T obj;

 public T getObj() {
     return obj;
 }

 public void setObj(T obj) {
     this.obj = obj;
 }
}

public class Program01 {

 public static void main(String[] args) {

     // Box to store Integer
     Box<Integer> b1 = new Box<Integer>();
     b1.setObj(10);                    // Set Integer
     Integer i1 = b1.getObj();         // Get Integer
     System.out.println("i1: " + i1);  // Print Integer

     // Box to store String
     Box<String> b2 = new Box<String>();
     b2.setObj("sunbeam");             // Set String
     String s1 = b2.getObj();          // Get String
     System.out.println("s1: " + s1);  // Print String
 }
}
