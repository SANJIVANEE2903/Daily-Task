package Demo03.p2;


import java.util.Arrays;

class Student implements Comparable<Student> {
	int rollNo;
	String name;
	double marks;

	public Student() {
	}

	public Student(int rollNo, String name, double marks) {
		this.rollNo = rollNo;
		this.name = name;
		this.marks = marks;
	}

	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", name=" + name + ", marks=" + marks + "]";
	}

	// 1. Sort by rollNo (ascending)
	//@Override
//	public int compareTo(Student o) {
//		return Integer.compare(this.rollNo, o.rollNo);
//	}
	// 2. Sort by rollNo (descending)
//		@Override
//	public int compareTo(Student o) {
//	    return o.rollNo - this.rollNo; // Descending
//	}

	// 3. Sort by name (alphabetical)
//	@Override
//	public int compareTo(Student o) {
//		return this.name.compareTo(o.name); // A-Z
//	}

	// 4. Sort by marks (descending)
//	@Override
//	public int compareTo(Student o) {
//		return Double.compare(o.marks, this.marks); // High to low
//	}
		
		@Override
		public int compareTo(Student o) {
		    return Double.compare(this.marks, o.marks); // Low to high
		}

}

public class Program02 {
	public static void main(String[] args) {
		Student[] arr = new Student[5];
		arr[0] = new Student(5, "Mukesh", 75.5);
		arr[1] = new Student(3, "Anil", 88.0);
		arr[2] = new Student(2, "Suresh", 67.5);
		arr[3] = new Student(1, "Ram", 92.3);
		arr[4] = new Student(4, "Ramesh", 78.9);

		System.out.println("Before sorting - ");
		for (Student student : arr)
			System.out.println(student);

		Arrays.sort(arr);

		System.out.println("\nAfter sorting - ");
		for (Student student : arr)
			System.out.println(student);
	}
}
	