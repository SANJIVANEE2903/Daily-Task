package Demo03.p2;


import java.util.Arrays;

class Product implements Comparable<Product> {
	int productId;
	String name;
	double price;

	public Product() {
	}

	public Product(int productId, String name, double price) {
		this.productId = productId;
		this.name = name;
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", name=" + name + ", price=" + price + "]";
	}

	// 1. Sort by productId (ascending)
	@Override
	public int compareTo(Product o) {
		return Integer.compare(this.productId, o.productId);
	}

	// 2. Sort by productId (descending)
//	@Override
//	public int compareTo(Product o) {
//		return Integer.compare(o.productId, this.productId);
//	}

	// 3. Sort by name (A-Z alphabetical)
//	@Override
//	public int compareTo(Product o) {
//		return this.name.compareTo(o.name);
//	}

	// 4. Sort by price (descending)
//	@Override
//	public int compareTo(Product o) {
//		return Double.compare(o.price, this.price);
//	}

	// 5.  Sort by price (ascending)
//	@Override
//	public int compareTo(Product o) {
//		return Double.compare(this.price, o.price);
//	}
}

public class Program03 {
	public static void main(String[] args) {
		Product[] arr = new Product[5];
		arr[0] = new Product(105, "Mouse", 599.0);
		arr[1] = new Product(103, "Monitor", 12500.0);
		arr[2] = new Product(102, "Keyboard", 999.0);
		arr[3] = new Product(101, "Laptop", 55000.0);
		arr[4] = new Product(104, "Pen Drive", 799.0);

		System.out.println("Before sorting - ");
		for (Product product : arr)
			System.out.println(product);

		Arrays.sort(arr); 

		System.out.println("After sorting - ");
		for (Product product : arr)
			System.out.println(product);
	}
}

