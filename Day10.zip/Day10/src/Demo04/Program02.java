package Demo04;

import java.util.Arrays;
import java.util.Scanner;

class Student implements Comparable<Student> {
	int rollNo;
	String name;
	double marks;
	
	// 1 = empid, 2 = name, 3 = salary
		static int sortChoice;
		static boolean isAscending;

	
	public Student(int rollNo, String name, double marks) {
		this.rollNo = rollNo;
		this.name = name;
		this.marks = marks;
	}

	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", name=" + name + ", marks=" + marks + "]";
	}
	
	@Override
	public int compareTo(Student o) {
		int result = 0;
		switch (sortChoice) {
			case 1:
				result = this.rollNo - o.rollNo;
				break;
			case 2:
				result = this.name.compareTo(o.name);
				break;
			case 3:
				result = Double.compare(this.marks, o.marks);
				break;
		}
		return isAscending ? result : -result;
	}
}

public class Program02 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter number of Students: ");
		int n = sc.nextInt();
		sc.nextLine();

		Student[] arr = new Student[n];

		for (int i = 0; i < n; i++) {
			System.out.println("\nEnter details for Student " + (i + 1));
			System.out.print("rollNo: ");
			int rollNo = sc.nextInt();
			sc.nextLine();
			System.out.print("Name: ");
			String name = sc.nextLine();
			System.out.print("marks: ");
			double marks = sc.nextDouble();
			sc.nextLine();
			arr[i] = new Student(rollNo, name, marks);
		}

		System.out.println("\nSort by:");
		System.out.println("1. Student rollNo ");
		System.out.println("2. Name");
		System.out.println("3. marks");
		System.out.print("Enter choice: ");
		Student.sortChoice = sc.nextInt();

		System.out.println("1. Ascending");
		System.out.println("2. Descending");
		System.out.print("Enter order: ");
		int order = sc.nextInt();
		Student.isAscending = (order == 1);

		System.out.println("\nBefore Sorting:");
		for (Student e : arr)
			System.out.println(e);

		Arrays.sort(arr);

		System.out.println("\nAfter Sorting:");
		for (Student e : arr)
			System.out.println(e);

		sc.close();
	}
}
