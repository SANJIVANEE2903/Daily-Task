package Demo04;


import java.util.Arrays;
import java.util.Scanner;


class Product implements Comparable<Product> {
	int productId;
	String name;
	double price;
	
	// 1 = empid, 2 = name, 3 = salary
		static int sortChoice;
		static boolean isAscending;

	
		public Product(int productId, String name, double price) {
			this.productId = productId;
			this.name = name;
			this.price = price;
		}

		@Override
		public String toString() {
			return "Product [productId=" + productId + ", name=" + name + ", price=" + price + "]";
		}
	
	@Override
	public int compareTo(Product o) {
		int result = 0;
		switch (sortChoice) {
			case 1:
				result = this.productId - o.productId;
				break;
			case 2:
				result = this.name.compareTo(o.name);
				break;
			case 3:
				result = Double.compare(this.price, o.price);
				break;
		}
		return isAscending ? result : -result;
	}
}

public class Program03 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter number of Products: ");
		int n = sc.nextInt();
		sc.nextLine();

		Product[] arr = new Product[n];

		for (int i = 0; i < n; i++) {
			System.out.println("\nEnter details for Product " + (i + 1));
			System.out.print("productId: ");
			int productId = sc.nextInt();
			sc.nextLine();
			System.out.print("Name: ");
			String name = sc.nextLine();
			System.out.print("price: ");
			double price = sc.nextDouble();
			sc.nextLine();
			arr[i] = new Product(productId, name, price);
		}

		System.out.println("\nSort by:");
		System.out.println("1. Product productId: ");
		System.out.println("2. Name");
		System.out.println("3.  price");
		System.out.print("Enter choice: ");
		Student.sortChoice = sc.nextInt();

		System.out.println("1. Ascending");
		System.out.println("2. Descending");
		System.out.print("Enter order: ");
		int order = sc.nextInt();
		Student.isAscending = (order == 1);

		System.out.println("\nBefore Sorting:");
		for (Product e : arr)
			System.out.println(e);

		Arrays.sort(arr);

		System.out.println("\nAfter Sorting:");
		for (Product e : arr)
			System.out.println(e);

		sc.close();
	}
}

