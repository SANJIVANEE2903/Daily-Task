package Demo04;

import java.util.Arrays;
import java.util.Scanner;

class Employee implements Comparable<Employee> {
	int empid;
	String name;
	double salary;

	// 1 = empid, 2 = name, 3 = salary
	static int sortChoice;
	static boolean isAscending;

	public Employee(int empid, String name, double salary) {
		this.empid = empid;
		this.name = name;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", salary=" + salary + "]";
	}

	@Override
	public int compareTo(Employee o) {
		int result = 0;
		switch (sortChoice) {
			case 1:
				result = this.empid - o.empid;
				break;
			case 2:
				result = this.name.compareTo(o.name);
				break;
			case 3:
				result = Double.compare(this.salary, o.salary);
				break;
		}
		return isAscending ? result : -result;
	}
}

public class Program01 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter number of employees: ");
		int n = sc.nextInt();
		sc.nextLine();

		Employee[] arr = new Employee[n];

		for (int i = 0; i < n; i++) {
			System.out.println("\nEnter details for employee " + (i + 1));
			System.out.print("ID: ");
			int id = sc.nextInt();
			sc.nextLine();
			System.out.print("Name: ");
			String name = sc.nextLine();
			System.out.print("Salary: ");
			double salary = sc.nextDouble();
			sc.nextLine();
			arr[i] = new Employee(id, name, salary);
		}

		System.out.println("\nSort by:");
		System.out.println("1. Employee ID");
		System.out.println("2. Name");
		System.out.println("3. Salary");
		System.out.print("Enter choice: ");
		Employee.sortChoice = sc.nextInt();

		System.out.println("1. Ascending");
		System.out.println("2. Descending");
		System.out.print("Enter order: ");
		int order = sc.nextInt();
		Employee.isAscending = (order == 1);

		System.out.println("\nBefore Sorting:");
		for (Employee e : arr)
			System.out.println(e);

		Arrays.sort(arr);

		System.out.println("\nAfter Sorting:");
		for (Employee e : arr)
			System.out.println(e);

		sc.close();
	}
}
