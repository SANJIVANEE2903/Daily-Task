//Q1. Declare two Arrays of type String. Find the duplicate values of an array of string values. (Hint:
//use equals())

package com.dkte;

public class Q1 {
	
	    public static void main(String[] args) {
            String[] array1 = { "a", "e", "i", "o", "u",};
	        String[] array2 = {"a", "d", "u", "h", "o"};

	    	
//	    	String[] array1 = {"Geeks",  "for",  "Geeks",  "String",  "in",  "Java"};
//	    	String[] array2 = {"Geeks",  "or",  "Geeks",  "String",  "in",  "python"};
	    	
//	    	String[] array1 = {"1",  "2",  "5",  "9",  "7",  "0"};
//	    	String[] array2 = {"8",  "7",  "0",  "9",  "8",  "0"};
	    	
	    	
	        System.out.println("Duplicate values between array1 and array2 are:");

	        for (int i = 0; i < array1.length; i++) {
	            for (int j = 0; j < array2.length; j++) {
	                if (array1[i].equals(array2[j])) {
	                    System.out.println(array1[i]);
	                    break; 
	                }
	            }
	        }
	    }
	}

