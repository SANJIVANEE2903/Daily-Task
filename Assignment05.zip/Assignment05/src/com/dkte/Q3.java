//Q3. Write a java code to check string is palindrome.

package com.dkte;

import java.util.Scanner;

public class Q3 {
	
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.print("Enter a string: ");
	        String str = sc.nextLine();

	        String reversed = "";
	        for (int i = str.length() - 1; i >= 0; i--) {
	            reversed += str.charAt(i);
	        }

	        if (str.equals(reversed)) {
	            System.out.println("The string is a Palindrome.");
	        } else {
	            System.out.println("The string is NOT a Palindrome.");
	        }
	        
	        sc.close();
	    }
	}

