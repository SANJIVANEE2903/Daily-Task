package Demo01;

public class Program03 {
            

	public static void main(String[] args) {
		Employee e1 = new Employee(1, "Anil", 10000, 1, 1, 2001);
		e1.displayEmployee();

	}
}
