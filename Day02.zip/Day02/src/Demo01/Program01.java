package Demo01;

public class Program01 {
        public static void main(String [] args) {
        	int num1 = 10;
        	double num2 = 10.25;
        	
        	System.out.println("num1:" +num1);
        	System.out.println("num2:" +num2);
        }
}
