package Demo01;

public class Program02 {
	public static void main(String[] args) {
		int num1 = 10;
		double num2 = num1; // Widening
		// Process of converting narrower type of data into the wider type

		double num3 = 20.57;
		int num4 = (int) num3; // Narrowing
		// Process of converting wider type of data into the narrower type
		// In the case of narrowing explicit type casting is mandatory
              
		
		System.out.println("num2:" +num2);
		System.out.println("num4:" +num4);
	}
}
