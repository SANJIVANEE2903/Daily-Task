package Demo01;

public class Program03 {

	public static void main(String[] args) {
		boolean status = true;
//		int num1 = (int) status; // NOT OK
//		double num2 = (double) status; // NOT OK

		// converting boolean type to any other type is
	    // not allowed in java
		
		System.out.println("status:" +status);
	}
}
