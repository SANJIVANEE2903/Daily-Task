package Demo02;

public class Program03 {
	public static void main(String[] args) {
        int num1 = 10;
        Integer i1 = num1; // AutoBoxing

        Double d1 = new Double(20.56);
        double num2 = d1; // AutoUnBoxing

        // Output
        System.out.println("Primitive num1 = " + num1);
        System.out.println("AutoBoxed Integer i1 = " + i1);

        System.out.println("Boxed Double d1 = " + d1);
        System.out.println("AutoUnboxed double num2 = " + num2);
    }
}
