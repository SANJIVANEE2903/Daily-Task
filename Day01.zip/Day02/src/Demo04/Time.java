package Demo04;

import java.util.Scanner;

class Time {
    int hr;
    int min;

    // Accept and validate input
    void accept(Scanner sc) {
        do {
            System.out.print("Enter hours (0-23): ");
            hr = sc.nextInt();
        } while (hr < 0 || hr > 23);

        do {
            System.out.print("Enter minutes (0-59): ");
            min = sc.nextInt();
        } while (min < 0 || min > 59);
    }

    // Display in 24-hour format
    void display24() {
        System.out.printf("Time (24-hour) = %02d:%02d\n", hr, min);
    }

    // Display in 12-hour format with AM/PM
    void display12() {
        int displayHr = hr % 12;
        if (displayHr == 0) displayHr = 12;
        String period = (hr < 12) ? "AM" : "PM";
        System.out.printf("Time (12-hour) = %02d:%02d %s\n", displayHr, min, period);
    }
}
