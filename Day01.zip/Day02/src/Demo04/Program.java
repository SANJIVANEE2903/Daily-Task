package Demo04;

import java.util.Scanner;

public class Program {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("How many time entries do you want to input? ");
        int n = sc.nextInt();

        Time[] times = new Time[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter time " + (i + 1));
            times[i] = new Time();
            times[i].accept(sc);
        }

        // Display all time objects
        for (int i = 0; i < n; i++) {
            System.out.println("\nTime " + (i + 1));
            times[i].display24();
            times[i].display12();
        }

        sc.close();
    }
}
