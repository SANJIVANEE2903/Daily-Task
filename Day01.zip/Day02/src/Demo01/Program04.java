package Demo01;

public class Program04 {
    public static void main(String[] args) {
        char ch = 'A';
        int num1 = ch;
        double num2 = ch;
        byte num3 = (byte) ch;

        byte num4 = 20;
        char ch2 = (char) num4;

        // Output the values
        System.out.println("char ch = " + ch);           // 'A'
        System.out.println("int num1 = " + num1);         // 65 (ASCII of 'A')
        System.out.println("double num2 = " + num2);      // 65.0
        System.out.println("byte num3 = " + num3);        // 65
        System.out.println("byte num4 = " + num4);        // 20
        System.out.println("char ch2 = " + ch2);          // Unicode char with ASCII 20 (non-printable)
    }
}
