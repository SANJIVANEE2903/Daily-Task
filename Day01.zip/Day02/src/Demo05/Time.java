package Demo05;

public class Time {
    int hr, min;

    public Time(int hr, int min) {
        this.hr = hr;
        this.min = min;
    }

    public void display() {
        System.out.printf("Time: %02d:%02d\n", hr, min);
    }

    public static void main(String[] args) {
        Time t = new Time(14, 45);
        t.display(); // Output: Time: 14:45
    }
}
