package Demo05;

import java.time.LocalDate;

public class Date {
    public static void main(String[] args) {
        LocalDate today = LocalDate.now();
        System.out.println("Today's Date: " + today);
    }
}
