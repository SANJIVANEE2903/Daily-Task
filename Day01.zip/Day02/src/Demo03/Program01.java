package Demo03;

class BankAccount {
    int accno;
    String name;
    double balance;

    // deposit money
    void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited " + amount + " to " + name + "'s account. New balance = " + balance);
    }

    // withdraw money
    void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Withdrawn " + amount + " from " + name + "'s account. New balance = " + balance);
        } else {
            System.out.println("Insufficient balance in " + name + "'s account!");
        }
    }
}

class Time {
    int hr;
    int min;
}

public class Program01 {

    public static void main(String[] args) {
        // Create Bank Accounts
        BankAccount a1 = new BankAccount();
        a1.accno = 1082;
        a1.name = "Sunil";
        a1.balance = 70000;

        BankAccount a2 = new BankAccount();
        a2.accno = 1002;
        a2.name = "Anil";
        a2.balance = 10000;

        BankAccount a3 = new BankAccount();
        a3.accno = 1003;
        a3.name = "Mukesh";
        a3.balance = 20000;

        // Perform Transactions
        a1.deposit(2000);
        a2.withdraw(5000);
        a3.withdraw(25000); // this will show insufficient balance

        // Create Time Objects (Corrected)
        Time t1 = new Time();
        t1.hr = 10;
        t1.min = 20;

        Time t2 = new Time();
        t2.hr = 12;
        t2.min = 20;

        Time t3 = new Time();
        t3.hr = 10;
        t3.min = 30;

        // Display Times
        System.out.println("Time t1: " + t1.hr + ":" + t1.min);
        System.out.println("Time t2: " + t2.hr + ":" + t2.min);
        System.out.println("Time t3: " + t3.hr + ":" + t3.min);
    }
}
