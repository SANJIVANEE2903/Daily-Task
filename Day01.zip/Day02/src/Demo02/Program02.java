package Demo02;

public class Program02 {
	public static void main(String[] args) {
        Integer i1 = new Integer(10); // Reference Type
        double num1 = i1.doubleValue(); // Manual Unboxing

        // Output
        System.out.println("Boxed Integer i1 = " + i1);
        System.out.println("Unboxed primitive double num1 = " + num1);
    }
}
