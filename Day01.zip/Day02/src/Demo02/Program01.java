package Demo02;

public class Program01 {

    public static void main(String[] args) {
        int num1 = 10; // primitive type
        Integer i1 = new Integer(10); // Explicit object creation
        Integer i2 = new Integer(num1); // Boxing

        // Output
        System.out.println("Primitive num1 = " + num1);
        System.out.println("Boxed Integer i1 = " + i1);
        System.out.println("Boxed Integer i2 (from num1) = " + i2);
    }
}

