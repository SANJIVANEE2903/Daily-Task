package Demo03;

import java.util.Scanner;

public class Manager extends Employee {
    private double bonus;

    public Manager() {
        super();
    }

    public Manager(int empid, double salary, double bonus) {
        super(empid, salary);
        this.bonus = bonus;
    }

    @Override
    public void accept(Scanner sc) {
        super.accept(sc);
        System.out.print("Enter Bonus: ");
        bonus = sc.nextDouble();
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Bonus: " + bonus);
    }
}
