package Demo03;

import java.util.Scanner;

public class Salesman extends Employee {
	double bonus;

	public Salesman() {
	}

	public Salesman(int empid, double salary, double bonus) {
		super(empid, salary);
		this.bonus = bonus;
	}

	@Override
	public void accept(Scanner sc) {
		super.accept(sc);
		System.out.println("Enter bonus - ");
		bonus = sc.nextDouble();
	}

	@Override
	public void display() {
		super.display();
		System.out.println("Bonus - " + bonus);
	}

}
