package p1;

import java.util.Scanner;

public class Time {
    int hr;
    int min;
    Scanner sc = new Scanner(System.in); 

    public void accept() {
        System.out.print("Enter hours: ");
        hr = sc.nextInt();
        System.out.print("Enter minutes: ");
        min = sc.nextInt();
    }

    public void display() {
        System.out.printf("Time = %02d:%02d\n", hr, min);
        sc.close(); 
    }
}
