package p2;

import p1.Time;

public class Program {

	public static void main(String[] args) {
		Time t1 = new Time();
		t1.accept();
		t1.display();
	}
}
