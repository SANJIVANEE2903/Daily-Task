package Demo01;

import java.util.Scanner;

public class Program03 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Define number of courses and students in each
        int[] studentCounts = new int[2]; // index 0 = CS, 1 = AI-DS
        String[] courseNames = {"CS", "AI-DS"};

        // Ask user for number of students in each course
        for (int i = 0; i < studentCounts.length; i++) {
            System.out.print("Enter number of students for " + courseNames[i] + " course: ");
            studentCounts[i] = sc.nextInt();
        }

        // Create ragged array
        StudentInfo[][] studentList = new StudentInfo[2][];
        for (int i = 0; i < 2; i++) {
            studentList[i] = new StudentInfo[studentCounts[i]];
        }

        // Accept student data for each course
        for (int i = 0; i < studentList.length; i++) {
            System.out.println("\nEnter data for " + courseNames[i] + " course:");
            for (int j = 0; j < studentList[i].length; j++) {
                sc.nextLine(); // clear buffer
                System.out.print("Enter name: ");
                String name = sc.nextLine();
                System.out.print("Enter roll number: ");
                int rollNo = sc.nextInt();
                System.out.print("Enter marks: ");
                double marks = sc.nextDouble();
                studentList[i][j] = new StudentInfo(name, rollNo, marks);
            }
        }

        // Display students course-wise
        System.out.println("\n----- Student List -----");
        for (int i = 0; i < studentList.length; i++) {
            System.out.println("\nCourse: " + courseNames[i]);
            for (int j = 0; j < studentList[i].length; j++) {
                studentList[i][j].display();
            }
        }

        sc.close();
    }
}
