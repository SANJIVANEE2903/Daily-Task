package Demo01;

import java.util.Scanner;

public class MyStudent {
    private String name;
    private int rollNo;
    private double marks;

    public void acceptStudent() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter name: ");
        name = sc.nextLine();
        System.out.print("Enter roll number: ");
        rollNo = sc.nextInt();
        System.out.print("Enter marks: ");
        marks = sc.nextDouble();
        sc.close();
    }

    public void displayStudent() {
        System.out.println("Name: " + name + ", Roll No: " + rollNo + ", Marks: " + marks);
    }

    public int getRollNo() {
        return rollNo;
    }
   
}
