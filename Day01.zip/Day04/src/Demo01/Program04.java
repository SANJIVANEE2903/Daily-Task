package Demo01;


import java.util.Scanner;

public class Program04 {
    public static int menu(Scanner sc) {
        System.out.println("--------------------");
        System.out.println("0. EXIT");
        System.out.println("1. Add Student");
        System.out.println("2. Display Students");
        System.out.println("3. Find Student by Roll No");
        System.out.print("Enter your choice - ");
        int choice = sc.nextInt();
        System.out.println("--------------------");
        return choice;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Student1[] students = new Student1[100];
        int count = 0;
        int choice;

        while ((choice = menu(sc)) != 0) {
            switch (choice) {
                case 1:
                    if (count < students.length) {
                        System.out.print("Enter name: ");
                        sc.nextLine(); // clear buffer
                        String name = sc.nextLine();
                        System.out.print("Enter roll number: ");
                        int rollNo = sc.nextInt();
                        System.out.print("Enter marks: ");
                        double marks = sc.nextDouble();
                        students[count++] = new Student1(name, rollNo, marks);
                        System.out.println("Student added successfully.");
                    } else {
                        System.out.println("Student array is full.");
                    }
                    break;

                case 2:
                    if (count == 0) {
                        System.out.println("No students to display.");
                    } else {
                        System.out.println("Displaying all students:");
                        for (int i = 0; i < count; i++) {
                            students[i].display();
                        }
                    }
                    break;

                case 3:
                    System.out.print("Enter roll number to search: ");
                    int searchRoll = sc.nextInt();
                    boolean found = false;
                    for (int i = 0; i < count; i++) {
                        if (students[i].getRollNo() == searchRoll) {
                            System.out.println("Student Found:");
                            students[i].display();
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        System.out.println("Student with roll number " + searchRoll + " not found.");
                    }
                    break;

                default:
                    System.out.println("Wrong choice.. :(");
                    break;
            }
        }

        System.out.println("Program terminated.");
        sc.close();
    }
}
