package Demo01;

public class StudentInfo {
	 private String name;
	    private int rollNo;
	    private double marks;

	    public StudentInfo(String name, int rollNo, double marks) {
	        this.name = name;
	        this.rollNo = rollNo;
	        this.marks = marks;
	    }

	    public void display() {
	        System.out.println("Name: " + name + ", Roll No: " + rollNo + ", Marks: " + marks);
	    }
}
